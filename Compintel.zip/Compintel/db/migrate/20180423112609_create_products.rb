class CreateProducts < ActiveRecord::Migration[5.1]
  def change
    create_table :products do |t|
      t.string :mall_name
      t.string :product_name
      t.string :brand
      t.string :description
      t.string :vitamin
      t.integer :quantity
      t.float :price
      t.float :weight
      t.string :protein
      t.string :carbohydrates
      t.string :fats
      t.string :sugar

      t.timestamps
    end
  end
end
