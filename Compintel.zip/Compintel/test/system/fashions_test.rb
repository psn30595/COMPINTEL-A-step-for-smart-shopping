require "application_system_test_case"

class FashionsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit fashions_url
  #
  #   assert_selector "h1", text: "Fashion"
  # end
end
