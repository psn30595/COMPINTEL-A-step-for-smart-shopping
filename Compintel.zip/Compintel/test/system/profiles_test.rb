require "application_system_test_case"

class ProfilesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit profiles_url
  #
  #   assert_selector "h1", text: "Profile"
  # end
end
