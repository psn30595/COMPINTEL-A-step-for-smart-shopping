
class RegistrationsController < Devise::RegistrationsController


#  prepend_before_action :check_captcha, only: [:create] # Change this to be any actions you want to protect.

    def initialize
        
    end 
    def check_captcha #captcha verification
        temp = Captcha_img.array
        @t = temp.split("~").map(&:to_i)
        @val = @t.second
        puts @t.second
        return val
#      unless verify_recaptcha
    end
        
end