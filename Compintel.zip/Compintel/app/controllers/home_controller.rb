class HomeController < ApplicationController
 # require 'cmp_min_no'
before_action :authenticate_user! #authentication for the user
  def index
    config.authorize_with do
      redirect_to main_app.root_path unless warden.user.admin == true
    end
   
    @products = Product.all
    @order_item = current_order.order_items.new
    
  end
  
  def home
  end
  
  def dashboard
  end
  
  def itemtype
    def ensure_admin #it ensures that the user who have logged in is admin or not if yes then redirect to the page or else it hides the button
      unless current_user && current_user.admin?
      render :text => "Access Error Message", :status => :unauthorized
      end
    end
  end
  
  
  
end
