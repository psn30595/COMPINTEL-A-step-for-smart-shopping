class CartsController < ApplicationController
	def show
		@order_items = current_order.order_items 
		#shows the current order which are order by the user
	end
end
