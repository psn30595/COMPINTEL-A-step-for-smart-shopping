class Product < ApplicationRecord
	has_many :order_items
	validates :mall_name, :product_name,:brand, :description, :vitamin, presence: true
     
    validates :quantity, :protein, :carbohydrates, :fats, :sugar, format: { with: /\A[0-9]+\z/,message: "accepts digits only!" }
   
end
