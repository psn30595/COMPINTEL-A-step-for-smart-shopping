class Profile < ApplicationRecord
  belongs_to :user #validation/unit testing for product
  	validates :firstname, :lastname, :dob, :gender, :address, presence: true
     
    validates :firstname, :lastname, :gender, :address, format: { with: /\A[0-9]+\z/,message: "accepts digits only!" }
   
end
