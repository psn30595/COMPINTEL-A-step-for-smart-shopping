class ProductObserver < ActiveRecord::Observer
   def after_update(record) #it checks the quantity for users
       if record.quantity == 0
         puts " Out of stock ! "
        else

         puts " Available "
       end
   end
end