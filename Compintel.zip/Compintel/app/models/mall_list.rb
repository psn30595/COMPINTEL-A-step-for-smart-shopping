class MallList < ApplicationRecord
end
