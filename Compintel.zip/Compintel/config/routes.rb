Rails.application.routes.draw do
    root :to => "home#index"
  resources :products
  resources :order_items
  resource :carts, only: [:show]
  
  get 'validate/home'

  resources :profiles
  
  devise_for :admins
  devise_for :users#, controllers: { registrations: "registrations" }
  get 'home/index'
   get 'home/itemtype'
  get 'home/home'
    get 'product/index'
 get 'profiles/home'
  get 'home/dashboard' => "/dashboard"


   get '/signedinuserprofile' => "profiles#signedinuserprofile"

#devise_for :users, path: 'users'
#devise_for :users, path_names: {sign_in: "login", sign_out: "logout"}



# root :to => "home#itemtype"

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
